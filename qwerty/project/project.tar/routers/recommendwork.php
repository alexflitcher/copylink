<?php
require_once 'api.php';
// Роутер
function route($method, $urlData, $formData) {

  $exm = new DataBaseWorked("localhost", "administrator", "123456", "prime");
    // Получение информации о товаре
    // GET /resraurantwork/{goodId}
    if ($method === 'GET' && count($urlData) === 1) {
        // Получаем id товара
        $restId = $urlData[0];
        $list = $exm->getReccomendById($restId);
        // Выводим ответ клиенту
        echo $list;
        return;
    }


    if ($method === 'GET' && count($urlData) === 2 && $urlData[0] == 'type' && $urlData[1] == 'all') {
      $restId = $urlData[0];
      $list = $exm->getListRecommend();
      echo $list;
      return;
    }

    if ($method === 'POST' && empty($urlData)) {
          $restName = $formData['menu_id'];
          $m = $exm->addRecommend($restName);
          $lastid = $exm->conn->insert_id;
          echo json_encode(array(array(
              'method' => 'POST',
              'id' => $lastid,
              'status' => $m
          )));
          return;
    }


        if ($method === 'PUT' && count($urlData) === 1) {
            $restId = $urlData[0];
            $restName = $formData['menu_id'];
            $m = $exm->changeRecommendById($restId, $restName);
            echo json_encode(array(array(
                'method' => 'PUT',
                'id' => $lastid,
                'status' => $m
            )));
            return;
        }


        if ($method === 'PATCH' && count($urlData) === 1) {
            $restId = $urlData[0];
            $restName = $formData['menu_id'];
            $m = $exm->changeRecommendById($restId, $restName);
            echo json_encode(array(array(
                'method' => 'PATCH',
                'id' => $restId,
                'status' => $m
            )));
            return;
        }

        if ($method === 'DELETE' && count($urlData) === 1) {
          $restId = $urlData[0];
          $m = $exm->deleteRecommend($restId);
          echo json_encode(array(array(
              'method' => 'DELETE',
              'id' => $restId,
              'status' => $m
          )));
          return;
        }


  header('HTTP/1.0 400 Bad Request');
  echo json_encode(array(
      'error' => 'Bad Request'
  ));
}


?>
