<?php
  $host = 'localhost';
  $db_user = 'administrator';
  $db_pass = '123456';
  $db = 'prime';
?>
