<?php
  class DataBaseWorked {
    private $host, $db_user, $db_pass, $db, $time_to_conn;
    public $conn;

    public function __construct($host, $db_user, $db_pass, $db) {
      $this->host = $host;
      $this->db_user = $db_user;
      $this->db_pass = $db_pass;
      $this->db = $db;

      $this->conn = new mysqli($host, $db_user, $db_pass, $db);

      if ($this->conn->connect_error) die("Произошла ошибка");
      $this->time_to_conn = time();
    }

    public function getListCatalogs() {
      $tmp_m = [];
      $query = "SELECT * FROM catalogs";
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[] = $row;

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }

    public function getListRecommend() {
      $tmp_m = [];
      $query = "SELECT * FROM recommendations";
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[] = $row;

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getListInfo() {
      $tmp_m = [];
      $query = "SELECT * FROM info";
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[] = array("id" => $row['id'],"countprod"=> $row['countprod'],"countappli" => $row['countappli'], "deliver" => $row['deliver'],"address" => $row['address'],"name" => $row['name'], "phone" => $row['phone'],"comment" => $row['comment'],"pay"=> $row['pay'],"timedel" => $row['timedel'],"idsprod" => explode(',', $row['idsprod']));

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }

    /* type */
    public function getListMenu() {
      $tmp_m = [];
      $query = "SELECT * FROM menu";
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[] =  $row;

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getListRestaurants() {
  $query = "SELECT * FROM restaurants";
  $result = $this->conn->query($query);
  if (!$result) return false;
  $data = array();
  while($n = $result->fetch_assoc()) {
   $data[] = $n;
  }
  return json_encode($data);
    }

    public function getCatalogById($id) {
      $id = htmlentities($id);
      $query = "SELECT * FROM catalogs WHERE id=?";
      $stmt = $this->conn->prepare($query);
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $res = $stmt->get_result();
      $result = $res->fetch_array(MYSQLI_ASSOC);
      if (!$result) return false;
      $m[] = $result;
      return json_encode($m, JSON_UNESCAPED_UNICODE);
    }

    public function getReccomendById($id) {
      $id = htmlentities($id);
      $query = "SELECT * FROM recommendations WHERE id=?";
      $stmt = $this->conn->prepare($query);
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $res = $stmt->get_result();
      $result = $res->fetch_array(MYSQLI_ASSOC);
      if (!$result) return false;
      $m[] = $result;
      return json_encode($m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getInfoById($id) {
      $id = htmlentities($id);
      $query = "SELECT * FROM info WHERE id=?";
      $stmt = $this->conn->prepare($query);
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $res = $stmt->get_result();
      $result = $res->fetch_array(MYSQLI_ASSOC);
      if (!$result) return false;
      $m[] = $result;
      return json_encode($m, JSON_UNESCAPED_UNICODE);
    }

    /* type */
    public function getRestaurantById($id) {
      $id = htmlentities($id);
      $query = "SELECT * FROM restaurants WHERE id=?";
      $stmt = $this->conn->prepare($query);
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $res = $stmt->get_result();
      $result = $res->fetch_array(MYSQLI_ASSOC);
      if (!$result) return false;
      $m[] = $result;
      return json_encode($m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getMenuByIdRestaurant($rest_id) {
      $rest_id = htmlentities($rest_id);
      $tmp_m = [];
      $query = "SELECT * FROM menu WHERE restaurant_id='$rest_id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[$i] = $row;

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getListCategoryByIdRestaurant($id) {
      $id = htmlentities($id);
      $query = "SELECT category, restaurant_id, id FROM menu WHERE restaurant_id=$id";
      $tmp_m = [];
      $result = $this->conn->query($query);
      if (!$result) return false;
      for ($i = 0; $i < $result->num_rows; $i++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $tmp_m[$i] = array("id" => $row['id'], "category"=>$row["category"]);

      }
      return json_encode($tmp_m, JSON_UNESCAPED_UNICODE);
    }
    /* type */
    public function getMenuById($id) {
      $id = htmlentities($id);
      $query = "SELECT * FROM menu WHERE id=?";
      $stmt = $this->conn->prepare($query);
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $res = $stmt->get_result();
      $result = $res->fetch_array(MYSQLI_ASSOC);
      if (!$result) return false;
      $m[] = $result;
      return json_encode($m, JSON_UNESCAPED_UNICODE);
    }


    public function changeCategoryById($id, $name) {
      $id = htmlentities($id);
      $name = htmlentities($name);
      $query = "UPDATE `catalogs` SET `name`='$name' WHERE `id`=$id ";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

    public function changeRecommendById($id, $menu_id) {
      $id = htmlentities($id);
      $menu_id = htmlentities($menu_id);
      $query = "UPDATE `recommendations` SET `menu_id`=$menu_id WHERE `id`=$id ";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function changeNameRestaurantById($id, $newname) {
      $id = htmlentities($id);
      $newname = htmlentities($newname);
      $query = "UPDATE restaurants SET name='$newname' WHERE id=$id";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function changeMenuById($id, $pathtoimage, $name, $category, $description, $price, $calories, $new, $oldprice, $newprice, $weight, $rest_id) {
      $id = htmlentities($id);
      $pathtoimage = htmlentities($pathtoimage);
      $name = htmlentities($name);
      $category = htmlentities($category);
      $description = htmlentities($description);
      $price = htmlentities($price);
      $calories = htmlentities($calories);
      $new = htmlentities($new);
      $oldprice = htmlentities($oldprice);
      $newprice = htmlentities($newprice);
      $weight = htmlentities($weight);
      $rest_id = htmlentities($rest_id);

      $query = "UPDATE menu SET image='$pathtoimage', name='$name', category='$category', description='$description', price='$price', calories='$calories', new='$new', oldprice='$oldprice', newprice='$newprice', weight='$weight', restaurant_id='$rest_id' WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function changeInfoById($id, $countprod, $countappli, $deliver, $address, $name, $phone, $comment, $pay, $timedel, $idsprod) {
      $id = htmlentities($id);
      $countprod = htmlentities($countprod);
      $countappli = htmlentities($countappli);
      $deliver = htmlentities($deliver);
      $address = htmlentities($address);
      $name = htmlentities($name);
      $phone = htmlentities($phone);
      $comment = htmlentities($comment);
      $pay = htmlentities($pay);
      $timedel = htmlentities($timedel);
      $idsprod = htmlentities($idsprod);
      $query = "UPDATE info SET countprod='$countprod', countappli='$countappli', deliver='$deliver', address='$address', name='$name', phone='$phone', comment='$comment', pay='$pay', timedel='$timedel', idsprod='$idsprod'   WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

    public function addCatalogs($name) {
      $name = htmlentities($name);
      $query = "INSERT INTO catalogs VALUES(null, '$name')";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

    public function addRecommend($menu_id) {
      $menu_id = htmlentities($menu_id);
      $query = "INSERT INTO recommendations VALUES(null, '$menu_id')";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function addPositionMenu($pathtoimage, $name, $category, $description, $price, $calories, $new, $oldprice, $newprice, $weight, $rest_id) {
      $pathtoimage = htmlentities($pathtoimage);
      $name = htmlentities($name);
      $category = htmlentities($category);
      $description = htmlentities($description);
      $price = htmlentities($price);
      $calories = htmlentities($calories);
      $new = htmlentities($new);
      $oldprice = htmlentities($oldprice);
      $newprice = htmlentities($newprice);
      $weight = htmlentities($weight);
      $rest_id = htmlentities($rest_id);
      $query = "INSERT INTO menu VALUES (null, '$pathtoimage', '$name','$category','$description','$price','$calories','$new','$oldprice', '$newprice', '$weight', '$rest_id')";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;

    }
    /* type */
    public function addRestaurant($name) {
      $name = htmlentities($name);
      $query = "INSERT INTO restaurants VALUES(null, '$name')";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function addInfo($countprod, $countappli, $deliver, $address, $name, $phone, $comment, $pay, $timedel, $idsprod) {
      $countprod = htmlentities($countprod);
      $countappli = htmlentities($countappli);
      $deliver = htmlentities($deliver);
      $address = htmlentities($address);
      $name = htmlentities($name);
      $phone = htmlentities($phone);
      $comment = htmlentities($comment);
      $pay = htmlentities($pay);
      $timedel = htmlentities($timedel);
      $idsprod = htmlentities($idsprod);
      $query = "INSERT INTO info VALUES (null, '$countprod', '$countappli', '$deliver', '$address', '$name', '$phone', '$comment', '$pay', '$timedel', '$idsprod')";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

    public function deleteCatalogs($id) {
      $id = htmlentities($id);
      $query = "DELETE FROM catalogs WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

    public function deleteRecommend($id) {
      $id = htmlentities($id);
      $query = "DELETE FROM recommendations WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function deletePositionMenu($id) {
      $id = htmlentities($id);
      $query = "DELETE FROM menu WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function deleteRestaurant($id) {
      $id = htmlentities($id);
      $query = "DELETE FROM restaurants WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }
    /* type */
    public function deleteInfo($id) {
      $id = htmlentities($id);
      $query = "DELETE FROM info WHERE id='$id'";
      $result = $this->conn->query($query);
      if (!$result) return false;
      else return true;
    }

}
?>
